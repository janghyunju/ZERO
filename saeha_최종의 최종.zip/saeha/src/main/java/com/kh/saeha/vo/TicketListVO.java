package com.kh.saeha.vo;

import java.util.List;

public class TicketListVO {

	 private List<TicketBuyVO> ticketlist;

	public List<TicketBuyVO> getTicketlist() {
		return ticketlist;
	}

	public void setTicketlist(List<TicketBuyVO> ticketlist) {
		this.ticketlist = ticketlist;
	}

	
}