package com.kh.saeha.dao;

import java.util.List;

import com.kh.saeha.vo.TicketBuyVO;

public interface TicketBuyDAO {

	public void insert(TicketBuyVO vo) throws Exception;
	
	//public List<TicketBuyVO> list() throws Exception;
	
	
}
