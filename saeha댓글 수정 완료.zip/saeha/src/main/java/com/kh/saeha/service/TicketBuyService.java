package com.kh.saeha.service;

import java.util.List;

import com.kh.saeha.vo.TicketBuyVO;

public interface TicketBuyService {

	public void insert(TicketBuyVO vo) throws Exception;
	
//	public List<TicketBuyVO> list() throws Exception;
	
}
